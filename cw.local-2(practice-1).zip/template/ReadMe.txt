Free Bootstrap Resume/CV Template for developers

Theme name:
=======================================================================
Orbit

Theme version:
=======================================================================
v1.0

Release Date:
=======================================================================
29 Jan 2016

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media (http://themes.3rdwavemedia.com/)

Contact:
=======================================================================
Web: http://themes.3rdwavemedia.com/
Email: hello@3rdwavemedia.com
Twitter: @3rdwave_themes

License: 
=======================================================================
This template is free under the Creative Commons Attribution 3.0 License.
https://creativecommons.org/licenses/by/3.0/
