<?php
return [
    'about' => [
        'name' => 'Александр Варыгин',
        'photo' => '',
        'email' => 'otz-job@mail.ru',
        'phone' => '+7(911)400-60-63',
        'site' => 'example.com',
        'post' => 'engineer',
    ],
    'education' => [
        [
            'title' => 'Школа',
            'speciality' => 'Школьник',
            'yearStart' => '1984',
            'yearEnd' => '1994',
        ],
        [
            'title' => 'Университет',
            'speciality' => 'Студент',
            'yearStart' => '1994',
            'yearEnd' => '1999',
        ],
    ],
    'languages' => [
        [
            'title' => 'English',
            'level' => 'Pre-intermediate'
        ],
        [
            'title' => 'Russian',
            'level' => 'Intermediate C4'
        ],
    ],
    'interests' => [
        'Кино',
        'Машины',
        'Программирование'
    ],
];